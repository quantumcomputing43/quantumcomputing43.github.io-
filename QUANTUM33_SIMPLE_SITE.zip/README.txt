QUANTUM33 — SIMPLE WEBSITE PACKAGE

This simplified version intentionally uses ONE file only:
    index.html

No style.css, no script.js, no archive.html, no miRNA21.html, no axion.html.
Everything needed for the main profile/site is inside index.html.

Why:
- avoids broken relative paths
- avoids moving multiple folders/files
- easy to upload to GitHub Pages
- old files can remain untouched in your repository

To use it:
1. Open the ZIP.
2. Take index.html.
3. Upload/replace ONLY the repository's main index.html if you want this to become the homepage.
4. Do NOT delete the old files unless you later decide to clean them up.
